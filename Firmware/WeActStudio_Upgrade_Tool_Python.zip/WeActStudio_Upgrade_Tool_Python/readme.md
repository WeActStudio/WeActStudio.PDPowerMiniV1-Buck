# WeActStudio Upgrade Tool Python
```
Usage: python WeActStudio_Upgrade_Tool.py [serial_port] <file_path>
Example 1 (Auto Search):  python WeActStudio_Upgrade_Tool.py firmware.fpk
Example 2 (Specify Port): python WeActStudio_Upgrade_Tool.py COM30 firmware.fpk
```